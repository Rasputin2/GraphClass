/*graph.h*/

//
// Simple graph class where vertices are single uppercase letters, 
// 'A'..'Z', and an adjacency matrix is used for the representation.
//
// Prof. Joe Hummel
// U. of Illinois, Chicago
// CS 251: Fall 2019
//

#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <limits>

#include "minqueue.h"

using namespace std;

class graph
{
private:
  int  Matrix[26][26];  // adjacency matrix
  bool Vertices[26];    // true if a vertex, false if not
  
  struct NODE {
	
	char Vertex;
	int  Distance;
	
  };

public:
  // default constructor:
  // Creates a Vector of Booleans to Track Active Vertices
  // Creates a Matrix to Store Graph Information
  graph()
  {
    
    // initialize the adjacency matrix, and the vertices:
    for (int i = 0; i < 26; ++i)
    {
      Vertices[i] = false;

      for (int j = 0; j < 26; ++j)
        Matrix[i][j] = -1;
    }
  }

  
  // numvertices:
  // Iterates through the vector of Booleans, 
  // counts how many are "true", and returns the count.
  int numvertices()
  {
    int count = 0;

    for (int i = 0; i < 26; ++i)
    {
      if (Vertices[i])
        count++;
    }

    return count;
  }

  // isvertex:
  // Converts the provided Alpha into a Number from 0 - 251
  // Returns the Boolean Truth Value of that Element of the Vector of Booleans
  bool isvertex(char v)
  {
    if (v < 'A' || v > 'Z')
      return false;

    int i = v - 'A';

    return Vertices[i];
  }

  // addvertex:
  // Sets the Relevant Element of a Vector of Booleans
  // to True if a new Vertex is Added
  bool addvertex(char v)
  {
    if (v < 'A' || v > 'Z')
      return false;

    int i = v - 'A';

    Vertices[i] = true;
    return true;
  }

  // addedge:
  // Converts the Alpha into a Row and Column
  // Location and Inserts Integer At that Location in Matrix
  bool addedge(char from, char to, int weight)
  {
    if (!isvertex(from) || !isvertex(to))
      return false;

    int i = from - 'A';
    int j = to - 'A';

    Matrix[i][j] = weight;
    return true;
  }

  // getweight:
  // Identifies the row and column
  // associated with two Vertices and Returns
  // the value in the Matrix associated with that
  // Grid Location
  int getweight(char from, char to)
  {
    if (!isvertex(from) || !isvertex(to))
      return -1;

    int i = from - 'A';
    int j = to - 'A';

    return Matrix[i][j];
  }

  // vertices:
  // Iterates through the vector of Booleans
  // if an element is True, it pushes the Alpha Associated
  // with that element into a vector and returns it
  vector<char> vertices()
  {
    vector<char>  V;

    for (int i = 0; i < 26; ++i)
    {
      if (Vertices[i])
        V.push_back('A' + i);
    }

    return V;
  }

  // neighbors:
  // Iterates Through the Row of the Matrix
  // Corresponding to startV and Returns those
  // Vertices with Whom startV has an Edge
  vector<char> neighbors(char v)
  {
    vector<char>  V;

    if (!isvertex(v))
      return V;

    int i = v - 'A';

    // loop along row, if there's an edge in the column then that
    // vertex is a neighbor:
    for (int j = 0; j < 26; ++j)
    {
      if (Matrix[i][j] >= 0)
        V.push_back(j + 'A');
    }

    return V;
  }

  // output:
  // Outputs graph to the console, typically for debugging purposes.
  void output()
  {
    vector<char> V = vertices();

    cout << "**Vertices: ";

    for (char c : V)
    {
      cout << c << " ";
    }

    cout << endl;

    cout << "**Edges: ";

    for (char v : V)
    {
      vector<char> adjacent = neighbors(v);

      for (char n : adjacent)
      {
        int weight = getweight(v, n);
        cout << "(" << v << "," << n << "," << weight << ") ";
      }
    }

    cout << endl;
  } // End of Output Function
  
};
