/*
 * 
 * This Function Links the Functions.cpp
 * to the main.cpp file
 * 
 */

#pragma once

#include <iostream>
#include <vector>
#include <string>

using namespace std;

bool buildGraph(string filename, graph& g);

vector<char> BFS(graph& g, char startV);
	
vector<char> DFS(graph& g, char startV);

void dAlgo(graph& g, char startV, vector <char> &visited, int (&distance)[26], int (&previous)[26]);