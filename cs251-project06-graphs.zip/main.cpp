/*
 * 
 * Project 06:
 * UIC CS 251
 * Author: John D. McDonald
 *
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <math.h>
#include <vector>
#include <queue>
#include <set>
#include <fstream>

#include "graph.h"
#include "minqueue.h"
#include "functions.h"

using namespace std;

// printVector Function:
// Used for the Repeated Printing of Returned Vectors
void printVector (string prefix, vector <char> &passedVector) {
	
	unsigned int i;
	
	cout << prefix;
	
	for (i = 0; i < passedVector.size(); ++i) {
		cout << passedVector[i] << " ";
	} // End for Loop
	
} // End of printVector Function

void printPrevious (int (&passedArray)[26], int startingPos) {
	
	vector <char> printedVector;
	int index;
	char vertexLetter;
	
	index = startingPos; // This is the "Ending Vertex" Passed from Main
	
	vertexLetter = index + 'A'; // Converts the Numeric to Alpha (i.e., 23 becomes 'X')
	
	// Store The Last Vertex at the Beginning of Vector We will Ultimately Print
	printedVector.insert(printedVector.begin(), vertexLetter);

	// Find the Path Back from Ending Vector to Starting Vector
	// And Push Each New Vertex In Front of the Last One
	while (passedArray[index] != -1) {
		
		vertexLetter = passedArray[index] + 'A';
		
		printedVector.insert(printedVector.begin(), vertexLetter); 
		
		index = passedArray[index];
		
	} // End of While Loop

	// Now We have the Trail of Vertices in Order
	// So Print Them
	for (unsigned int i = 0; i < printedVector.size(); ++i) {
		
		cout << " " << printedVector[i]; 
		
	} // End of For Loop
	
} // End of printPrevious

int main () {
	
 // Declare Variables
 string fileName; // Stores the fileName with Graph Data 	
 vector <char> activeVertices; // Stores a List of the Active Vertices in Order 
 vector <char> neighbors; 
 vector <char> BFSVector;
 vector <char> DFSVector;
 graph myGraph; // This Object Stores: (i) The Vector of ActiveVertices; and (ii) the Matrix
 char startV; // Stores the Starting Vertex for any Search
 
	
 // Get File Name for User Input
 cout << "Enter filename containing graph data> ";
 cin >> fileName;
 
 // Open File, Read File, and Store Information in Graph
 // The Purpose of the Boolean is Just to Check Whether the File Opened or Not
 bool open;
 
 open = buildGraph(fileName, myGraph);

 if (!open) {
	 return 0;
 }
 
 //Display the Vertices on the Console
 //Step One: Store the Vertices in a Vector
 //Step Two: Print the Vector
 activeVertices = myGraph.vertices();

 //Display the Edges on the Console
 myGraph.output();

 cout << endl;

 // Request User Input
 cout << "Enter a starting vertex or #> ";
 cin >> startV;
 
 while (!myGraph.isvertex(startV)) {
	 if (startV == '#') {
		break;
	 }
	 cout << "Not a vertex in graph, ignored..." << endl;
	 cout << endl;
	 cout << "Enter a starting vertex or #> ";
	 cin >> startV;
 }
	
 while (startV != '#') {
	 
	// Display Neighbors to Console
	neighbors = myGraph.neighbors(startV);
	printVector("Neighbors: ", neighbors);
	cout << endl;
	
	// Display BFS Results to Console
	BFSVector = BFS(myGraph, startV);
	printVector("BFS: ", BFSVector);
	cout << endl;
	
	// Display DFS Results to Console
	DFSVector = DFS(myGraph, startV);
	printVector("DFS: ", DFSVector);
	cout << endl;
	
	// Display Djikstra Results to Console
	// This Should Create the Minqueue
	
	vector <char> visited;
	int distance[26];
	int previous[26];
	int index;
	 
	dAlgo(myGraph, startV, visited, distance, previous);

    // We Know Have Three (3) Pieces of Information:
    // (i)   The Order The Vertices Were Visited
    // (ii)  The Predecessors of Each Vertex
    // (iii) The Distance Associated With Each Vertex
	cout << "Dijkstra:";
	 
	for (unsigned int i = 0; i < visited.size(); ++i) {
		
		cout << " " << visited[i];
	
	} // End of For Loop

   cout << endl;
 	 
   for (unsigned int i = 0; i < visited.size(); ++i) 
   {
	index = visited[i] - 'A';	
	cout << " " << visited[i] << ": " << distance[index] << " via ";
	  
	printPrevious(previous, index); // Calls a Function to Iterate Through the Trail Back
	
	cout << endl;
		
	} // End Outer Loop
  
   cout << endl;
	 
   // Request User Input to Begin While Loop Again
   cout << "Enter a starting vertex or #> ";
   cin >> startV;

   while (!myGraph.isvertex(startV)) {
	 if (startV == '#') {
		break;
	 } // End If Conditional
	 cout << "Not a vertex in graph, ignored..." << endl;
	 cout << endl;
	 cout << "Enter a starting vertex or #> ";
	 cin >> startV;
   } // End While 
	 
 } // End of While

 return 0;
} // End of Main 